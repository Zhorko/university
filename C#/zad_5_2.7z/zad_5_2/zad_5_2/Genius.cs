﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_2
{
    class Genius : Student
    {

        public Genius(int num, string name)
            : base(num, name) { }


        public new bool Test()
        {
            if (num >= 1)
            {
                check = true;
            }
            else
            {
                if (num < 1)
                    check = false;

            }
            return check;
        }

        public new void Info()
        {
            Console.WriteLine("Имя: {0}", name);
            if (check)
                Console.WriteLine("зачет сдал");
            else
                Console.WriteLine("зачет не сдал");
            Console.WriteLine("посетил занятий: {0}", num);
        }
    }
}
