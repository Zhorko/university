﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_3_fix
{
    class Rectangular : ITriangle
    {
        private double s;
        private double a;
        private double b;
        private double p;

        public Rectangular(double a, double b)
        {
            this.a = a;
            this.b = b;
        }

        public double Sqr()
        {
            this.s = (a * b) / 2;
            return s;
        }

        public double perimeter()
        {
            double c = Math.Sqrt(a * a + b * b);
            this.p = a + b + c;
            return p;
        }

        public void Str()
        {
            Console.WriteLine("Площадь = {0}", this.s);
            Console.WriteLine("Периметр = {0}", this.p);
        }
    }
}
