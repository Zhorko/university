﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication7
{
    class Program
    {
        static void Main(string[] args)
        {

            Massive rr = new Massive("2:3:4:5");
            Massive nn = new Massive(20);

            Console.WriteLine("сумма");
            Console.WriteLine(nn.sum_mod());
            rr.print();
            nn.print();
            Console.ReadKey();

        }

        class Massive
        {
            int[] arr;
            //string[] s1;
            int size;
            public Massive(string s)
            {
                string[]s1 = s.Split(':');
                this.size = s1.Length;
                arr = new int[this.size];
                for (int i = 0; i < this.size; i++)
                {
                    arr[i] = Convert.ToInt32(s1[i]);
                }
            }

            public Massive(int n)
            { 
                this.size = n;
                 arr = new int[this.size];
                Random rand = new Random();

                for (int i = 0; i < this.size; i++)
                {
                    int t = rand.Next(-50, 50);
                    if (t >= 0)
                    {
                        arr[i] = i;
                    }
                    else
                    {
                        arr[i] = -i;
                    }

                }
            }

            public int Max_new
            {
                get
                {
                    int max = arr[0];
                    for (int i = 1; i < this.size; i++)
                    {
                        if (max < arr[i])
                        {
                            max = arr[i];
                        }
                    }
                    return max;
                }


            }

            public void print()
            {
                Console.WriteLine();
                for (int i = 0; i < this.size; i++)
                    Console.Write(" {0} ", arr[i]);
                Console.WriteLine();
            }

            public int sum_mod()
            {
                int pfe = 0;
                int sum = 1;
                for (int i = 0; i < this.size - 1; i++)
                {
                    if (this.arr[i] > 0)
                    {
                        pfe = i;
                        break;
                    }
                }

                for (int i = pfe - 1; i > 0; i--)
                {
                    sum *= Math.Abs(arr[i]);
                }
                return sum;
            }
        }
    }
}
