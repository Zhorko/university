﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_3_fix
{
    class Equilateral : ITriangle
    {
        private double s;
        private double a;
        private double p;

        public Equilateral(double a)
        {
            this.a = a;
        }

        public double Sqr()
        {
            this.s = (a * a * Math.Sqrt(3)) / 4;
            return s;
        }

        public double perimeter()
        {
            this.p = a * 3;
            return p;
        }

        public void Str()
        {
            Console.WriteLine("Площадь = {0}", this.s);
            Console.WriteLine("Периметр = {0}", this.p);
        }
    }
}
