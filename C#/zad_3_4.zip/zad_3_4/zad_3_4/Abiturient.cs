﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_3_4
{
    class Abiturient
    {
        public string   name        { get; set; }
        public string   surname     { get; set; }
        public string   exam        { get; set; }
        public string   faculty     { get; set; }
        public int      mark        { get; set; }
        public int      pass_mark   { get; set; }

        public Abiturient()
        {
            surname = "";
            faculty = "";
            name = "";
            exam = "";
            mark = 0;
        }

        public Abiturient(string name, string surname, string exam, string faculty)
        {
            this.surname = surname;
            this.name = name;
            this.exam = exam;
            this.faculty = faculty;

            exam_num(exam);
            name_fix(name);
            surname_fix(surname);
        }

        private string exam_num(string s)
        {
            if (s.Length == 0)
            {
                Console.WriteLine("Non-valid name!");
            }
            return s;
        }

        public void check_mark()
        {
            
            Console.WriteLine("Mark is: {0}", mark);
        }

        private string name_fix(string s)
        {
            int s1 = s.Length - 1;

            if (s[0] == ' ')
                s.Remove(0, 1);

            if (s1 == ' ')
                s.Remove(s1, 1);

            return s;
        }

        private string surname_fix(string s)
        {
            if (s[0] == ' ')
                s.Remove(0, 1);

            if (s.Length - 1 == ' ')
                s.Remove(s.Length - 1, 1);

            return s;
        }

        public void print()
        {
            if (mark < pass_mark)
            {
                Console.WriteLine();
                Console.WriteLine("Name of student is: {0}", name);
                Console.WriteLine("Surname of student is: {0}", surname);
                Console.WriteLine("Faculty is: {0}", faculty);
                Console.WriteLine("{0} {1} не прошел на факультет из-за низкого балла по {2}, при проходном {3}", name, surname, exam, pass_mark);
            }
        }
    }
}
