﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_3_fix
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            int a = Convert.ToInt32(s);

            string s1 = Console.ReadLine();
            int b = Convert.ToInt32(s1);

            Console.WriteLine("Тип треугольника: равносторонний, прямоугольный, равносторонний");
            Console.WriteLine();
            string s2 = Console.ReadLine();

            if (s2 == "равносторонний")
            {
                ITriangle rs = new Equilateral(a);
                rs.perimeter();
                rs.Sqr();
                rs.Str();
            }
            else
            {
                if (s2 == "прямоугольный")
                {
                    ITriangle pg = new Rectangular(a, b);
                    pg.perimeter();
                    pg.Sqr();
                    pg.Str();
                }
                else
                {
                    if (s2 == "равносторонний")
                    {
                        ITriangle rt = new Isosceles(a, b);
                        rt.perimeter();
                        rt.Sqr();
                        rt.Str();
                    }
                }
            }
        }
    }
    public interface ITriangle
    {
        double Sqr();
        double perimeter();
        void Str();
    }
}
