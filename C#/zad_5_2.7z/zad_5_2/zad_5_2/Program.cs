﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Ordinary ord = new Ordinary(20, "обычный");
            Smart sm = new Smart(10, "умный");
            Genius gn = new Genius(1, "гений");

            ord.Test();
            ord.Info();
            Console.WriteLine();

            sm.Test();
            sm.Info();
            Console.WriteLine();

            gn.Test();
            gn.Info();
            Console.WriteLine();
        }
    }
}
