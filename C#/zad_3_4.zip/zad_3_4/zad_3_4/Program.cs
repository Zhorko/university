﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_3_4
{
    class Program
    {
        static void Main(string[] args)
        {
            List < Abiturient> ab = new List<Abiturient>();
            Random rand = new Random();

            string name, surname, exam, faculty;
            int mark, pass_mark = rand.Next(100, 120);

            Console.Write("Enter your name: ");
            name = Console.ReadLine();

            Console.Write("Enter your surname: ");
            surname = Console.ReadLine();


            Console.WriteLine("What is name of our exam? ");
            exam = Console.ReadLine();

            Console.Write("Enter your faculty: ");
            faculty = Console.ReadLine();

            Console.Write("Enter your mark: ");
            string s = Console.ReadLine();
            mark = Convert.ToInt32(s);

            ab.Add(new Abiturient { name = name, surname = surname, exam = exam, faculty = faculty, mark = mark });
           // var smth = ab.Where(x => (x.mark < x.pass_mark));

            foreach (Abiturient xx in ab)
            {
                if (xx.mark < pass_mark)
                    Console.WriteLine("Имя: {0}, Фамилия: {1}, Экзамен: {2}, Факультет: {3}, Оценка: {4}, Проходной: {5}", name, surname, exam, faculty, mark, pass_mark);
            }
        }
    }
    
}