﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_3_fix
{
    class Isosceles : ITriangle
    {
        private double s;
        private int a;
        private int b;
        private double p;

        public Isosceles(int a, int b)
        {
            this.b = b;
            this.a = a;
        }

        public double Sqr()
        {
            this.s = 1 / 4 * b * Math.Sqrt((4 * a * a) - (b * b));
            return s;
        }

        public double perimeter()
        {
            this.p = a + b;
            return p;
        }

        public void Str()
        {
            Console.WriteLine("Площадь = {0}", this.s);
            Console.WriteLine("Периметр = {0}", this.p);
        }
    }
}
