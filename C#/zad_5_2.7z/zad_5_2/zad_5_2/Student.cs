﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5_2
{
    class Student
    {
        protected string name;
        protected int num;
        protected bool check;

        public Student()
        {
            name = "";
            num = 0;
        }

        public Student(int num, string name)
        {
            this.num = num;
            this.name = name;
        }

        public virtual bool Test()
        {
            if (check == true)
                Console.WriteLine("Сдал зачет");
            else
                Console.WriteLine("Не сдал зачет");
            return check;
        }

        public virtual void Info()
        {
            Console.WriteLine("Имя: {0}", name);
        }
    }
}
